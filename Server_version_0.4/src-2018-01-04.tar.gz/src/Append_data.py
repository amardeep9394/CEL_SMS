#!/usr/bin/python

import time


f= open("/home/amardeep/Desktop/Server_version_0.3/data/msdState.json","w+")

f.write("+918375832916,2017/11/01,15:30:30,%HOk,Ok,5$")

f.close()
