#!/usr/bin/python

from bottle import get, post, request, Bottle, run, auth_basic, template, static_file # or route
#from Data_Processing import Data_Process
from main_function import generate_ts_id
from Show_data import Display_data
from collections import OrderedDict
from Search import Search_Data
from Prepare_query import Prepare_Query
from insert_sms_data import sms_process
from data_insert import insert
from insert_data import insert_system_detail
import os
import subprocess
import csv


app = Bottle()
dp = {}
config = {}
result1 = ()
URL = ""
Region = "Northern"
ab= os.path.dirname(os.getcwd())
path = ab+'/template/'

credential_url = ""
file_upload_data = []
#it is used to display all the templates with the help of bottle on the browser in server
class Server():	
	@app.route('/')
	def hello():
    		return template(path+'main.tpl')


	@app.route('/home')
	def serve_homepage1():
		#sd= eval(open('test.py').read())
		#d = generate_ts_id()
		#x = d.create_ts_signal(sd)
		url = request.url
		if "fileToUpload" in url:
			#http://10.26.22.138:8080/home?sysid=HASSDAC02&region=Northern&fileToUpload=dbbackup.py#
			file_upload_data = []
			url1 = url.split("?")
			url2 = url1[1].split("&")
			data_lst = []
			for url_ele in url2:
				data = url_ele.split("=")
				file_upload_data.append(data[1])
			#print file_upload_data
			file_name = file_upload_data[2]
			command = ['locate', file_name]
			output = subprocess.Popen(command, stdout=subprocess.PIPE).communicate()[0]
			output = output.decode()
			search_results = output.split('\n')
			upload_path = search_results[0]
			print "server",upload_path
			obj = insert()
			obj.search_pkt_in_file(file_upload_data,upload_path)
			#print pathfile
			
		else:
			global credential_url
			credential_url = url
		
		'''if 'sysid' in url and 'reg' in url and 'div' in url and 'systype' in url:
			url1 = credential_url.split("?")
			url2 = url1[1].split("&")
			data_lst = []
			for url_ele in url2:
				data = url_ele.split("=")
				data_lst.append(data[1])
			print data_lst'''

		#print "upload",url
		url1 = credential_url.split("?")
		url2 = url1[1].split("&")
		data_lst = []
		for url_ele in url2:
			data = url_ele.split("=")
			data_lst.append(data[1])
		print data_lst

		# check if insert system information form is requested
		if 'sysid' in url and 'reg' in url and 'div' in url and 'systype' in url:

			original_data = []
			# change mobile number format
			#data_lst[5] = '+91'+data_lst[5]
			# organize data
			for data in data_lst:

				if '+' in data:
					original_data.append(data.replace('+',' '))
				#if '%2B' in data:
					#original_data.append(data.replace('%2B','+'))
				else:
					original_data.append(data)
			original_data[5] = '+91'+original_data[5]
			print "changed data", original_data
			obj = insert_system_detail()
			obj.sql_query_to_insert(original_data)
			print "INSERT SUCCESSFULLY",original_data

		d = Display_data()
		#check = d.check_user(data_lst)
		#print "check",check
		
		#if len(check) == 1:
		if True:
			global Region
			#Region = data_lst[2]
			x = d.retrieve_data_for_table1(Region)
			#print "A",x
			test = {
				'Total': [x["MSDAC"]["Total"],x["HASSDAC"]["Total"],0],
				'System Type':['MSDAC','HASSDAC','SSDAC'],
				'Ok':[x["MSDAC"]["OK"],x["HASSDAC"]["OK"],0],
				'S. No': ['1','2','3'],
				'Unknown':[x["MSDAC"]["Unknown"],x["HASSDAC"]["Unknown"],0]
			}

			test_cases = len(test['S. No'])
		
			return template(path+'table_all_sys.tpl',rows = test, cases = test_cases)
		else:
			return template(path+'main1.tpl')
	
	
	# Show the details of all the MSDAC Information
	@app.route('/page1/MSDAC')
	def serve_homepage2():
		#print "request.url1",request.url
		#sd= eval(open('test.py').read())
		#d = generate_ts_id()
		#x = d.create_ts_signal(sd)

		#y = serve_homepage()

		d = Display_data()
		x = d.retrieve_data_for_table2(Region)
		#print "tsinfo",x
		test1 = OrderedDict()
		test1['S. No'] = x["MSDAC"]["S No."]
		test1['MSDAC ID'] = x["MSDAC"]["MSDAC ID"]
		test1['Station Name'] = x["MSDAC"]["Station Name"]
		test1['Status'] = x["MSDAC"]["Status"]
		#test1['Status'] = x["MSDAC"]["Updated_TS_Info"]
		test1['No. of DP'] = x["MSDAC"]["No. of DP"]
		test1['No. of TS'] = x["MSDAC"]["No. of TS"]
		test1['Date'] = x["MSDAC"]["Date"]
		test1['Time'] = x["MSDAC"]["Time"]
		test_cases1 = len(test1['No. of DP'])
		test_cases2 = len(test1['Status'])

		return template(path+'table_all_MSDAC.tpl',rows = test1, cases = test_cases1 , case2 = test_cases2)
	# Show the details of all the HASSDAC Information	
	@app.route('/page1/HASSDAC')
	def serve_homepage2():
		
		d = Display_data()
		x = d.retrieve_data_for_hassdac(Region)
		test1 = OrderedDict()
		test1['S. No'] = x["HASSDAC"]["S No."]
		test1['HASSDAC ID'] = x["HASSDAC"]["HASSDAC ID"]
		test1['Station Name'] = x["HASSDAC"]["Station Name"]
		test1['Status'] = x["HASSDAC"]["Status"]
		#test1['Status'] = x["MSDAC"]["Updated_TS_Info"]
		test1['System1 Status'] = x["HASSDAC"]["System1 Status"]
		test1['System2 Status'] = x["HASSDAC"]["System2 Status"]
		test1['Date'] = x["HASSDAC"]["Date"]
		test1['Time'] = x["HASSDAC"]["Time"]
		test_cases1 = len(test1['S. No'])
		#test_cases2 = len(test1['Status'])
		return template(path+'table_all_HASSDAC.tpl',rows = test1, cases = test_cases1)

	#show the history of one HASSDAC information
	@app.route('/page3/<url:re:.+>/hassdac')
	def server_hassdac(url):
		x = request.url
		ID = x.split("/")[-2]
		print "HASSDACID",ID
		d = Display_data()
		x = d.retrieve_data_for_hassdacid(ID)
		test1 = OrderedDict()
		test1['S. No'] = x["HASSDAC"]["S No."]
		test1['HASSDAC ID'] = x["HASSDAC"]["System_ID"]
		#test1['Station Name'] = x["HASSDAC"]["Station Name"]
		#test1['Status'] = x["HASSDAC"]["Status"]
		#test1['Status'] = x["MSDAC"]["Updated_TS_Info"]
		test1['System1 Status'] = x["HASSDAC"]["System1 Status"]
		test1['System2 Status'] = x["HASSDAC"]["System2 Status"]
		test1['Date'] = x["HASSDAC"]["Date"]
		test1['Time'] = x["HASSDAC"]["Time"]
		test_cases1 = len(test1['S. No'])
		#test_cases2 = len(test1['Status'])
		return template(path+'history_one_HASSDAC.tpl',rows = test1, cases = test_cases1,ID=ID)


	# Show all the details of all the DP
	@app.route('/page2/<url:re:.+>/dp')
	def serve_homepage3(url):
		x = request.url
		ID = x.split("/")[-2]
		#print "DP"
		#sd= eval(open('test.py').read())
		#d = generate_ts_id()
		#x = d.create_ts_signal(sd)

		#y = serve_homepage()

		d = Display_data()
		x = d.retrieve_data_for_dp(ID)
		y = d.retrieve_data_for_one_ID(ID)
		test1 = OrderedDict()
		#test1['S. No'] = x["MSDAC"]["S No."]
		test1['MSDAC ID'] = y["MSDAC"]["MSDAC ID"]
		test1['Station Name'] = y["MSDAC"]["Station Name"]
		test1['Status'] = y["MSDAC"]["Status"]
		#test1['Status'] = y["MSDAC"]["Updated_TS_Info"]
		test1['No. of DP'] = y["MSDAC"]["No. of DP"]
		test1['No. of TS'] = y["MSDAC"]["No. of TS"]
		test1['Date'] = y["MSDAC"]["Date"]
		test1['Time'] = y["MSDAC"]["Time"]
		test_cases1 = len(test1['No. of DP'])

		test2 = OrderedDict()
		test2['S. No'] = x["MSDAC"]["S No."]
		test2['DP ID'] = x["MSDAC"]["DP ID"]
		#test2['DP Status'] = x["MSDAC"]["DP Status"]
		test2['Error Code'] = x["MSDAC"]["Error Code"]
		test2['Date'] = x["MSDAC"]["Date"]
		test2['Time'] = x["MSDAC"]["Time"]
		test_cases2 = len(test2['S. No'])

		return template(path+'table_all_DP.tpl',rows = test2, cases = test_cases2,ID=ID,rows1=test1, cases1 = test_cases1)

	# Show all the details of all the TS
	@app.route('/page2/<url:re:.+>/ts')
	def serve_homepage3(url):
		x = request.url
		ID = x.split("/")[-2]
		#print ID
		#sd= eval(open('test.py').read())
		#d = generate_ts_id()
		#x = d.create_ts_signal(sd)

		#y = serve_homepage()

		d = Display_data()
		x = d.retrieve_data_for_table3(ID)
		y = d.retrieve_data_for_one_ID(ID)
		test1 = OrderedDict()
		#test1['S. No'] = x["MSDAC"]["S No."]
		test1['MSDAC ID'] = y["MSDAC"]["MSDAC ID"]
		test1['Station Name'] = y["MSDAC"]["Station Name"]
		test1['Status'] = y["MSDAC"]["Status"]
		#test1['Status'] = y["MSDAC"]["Updated_TS_Info"]
		test1['No. of DP'] = y["MSDAC"]["No. of DP"]
		test1['No. of TS'] = y["MSDAC"]["No. of TS"]
		test1['Date'] = y["MSDAC"]["Date"]
		test1['Time'] = y["MSDAC"]["Time"]
		test_cases1 = len(test1['No. of DP'])

		test2 = OrderedDict()
		test2['S. No'] = x["MSDAC"]["S No."]
		test2['TS Name'] = x["MSDAC"]["TS Name"]
		test2['TS Status'] = x["MSDAC"]["Track Section Status"]
		test2['Remark'] = x["MSDAC"]["Remark"]
		test2['Date'] = x["MSDAC"]["Date"]
		test2['Time'] = x["MSDAC"]["Time"]
		test_cases2 = len(test2['S. No'])

		return template(path+'table_all_TS.tpl',rows = test2, cases = test_cases2,ID=ID, rows1=test1, cases1 = test_cases1 )




	@app.route('/hello',method=['POST'])
	def hello():
		#print "X"
		#req=request.query_string # to receive all string from url in between ? and #
		urlparts = request.urlparts
		#print urlparts.scheme
		#print "CLIENT IP ADDRESS: ",urlparts.netloc.split(':')[0]
		print request.auth[0],request.auth[1]
		if request.auth[0]=='abhi' and request.auth[1]=='masamb':
			print "AUTHORISED USER"
			return "AUTHORISED USER"
			print "CCCC"
		else:
			return "UN-AUTHORISED USER"

	@app.route('/hello/msdacdata',method=['POST'])
	def data():
		#req=request.query_string # to receive all string from url in between ? and #
		urlparts = request.urlparts
		#print urlparts.scheme
		#print "CLIENT IP ADDRESS: ",urlparts.netloc.split(':')[0]
		#print request.headers['Content-Type']
		data = request.body.readlines()[0]
		#print data
		with open('test.py','w') as f:
			f.write(data)
		f.close()
		sd= eval(open('test.py').read())
		#print sd
		
		d = generate_ts_id()
		d.create_ts_signal(sd)
		#dp = Data_Process(sd)

	@app.route('/hello/msdacsms',method=['POST'])
	def data():
		#req=request.query_string # to receive all string from url in between ? and #
		urlparts = request.urlparts
		#print urlparts.scheme
		#print "CLIENT IP ADDRESS: ",urlparts.netloc.split(':')[0]
		#print request.headers['Content-Type']
		sms = request.body.readlines()[0]
		print "server",sms
		with open('test.py','w') as f:
			f.write(sms)
		f.close()
		sd= open('test.py').read()
		#print "sms",sd
		d = sms_process()
		d.break_sms_data(sd)
		

	@app.route('/static/<filename:re:.*\.css>', name = 'static')
	def stylesheets(filename):
		print ab+'/static/'
    		return static_file(filename, root=ab+'/static/')

	@app.route('/static/<filename:re:.*\.png>', name = 'static')
	def stylesheets(filename):
		print ab+'/static/'
    		return static_file(filename, root=ab+'/static/')
	
	
	#history of Track section of particular MSDAC
	@app.route('/history_result/<url:re:.+>/one_ts')
	def history_of_one_ts(url):
		x = request.url
		print "url---without date",x
		msdac_id = x.split("/")[4]
		msdac_id = msdac_id.split("%20")[0]
		#date = x.split("/")[-3].split("%20")
		ts_name = x.split("/")[-2]
		#sdate = date[1]
		#edate = date[3]
		print msdac_id,ts_name
		obj = Search_Data()
		#x = obj.history_msdac_of_one_ts(sdate,edate,msdac_id,ts_name)
		x = obj.history_msdac_of_one_ts(msdac_id,ts_name)
		test2 = OrderedDict()
		test2['S. No'] = x["MSDAC"]["S No."]
		test2['TS Status'] = x["MSDAC"]["Track Section Status"]
		test2['Remark'] = x["MSDAC"]["Remark"]
		test2['Date'] = x["MSDAC"]["Date"]
		test2['Time'] = x["MSDAC"]["Time"]
		test_cases2 = len(test2['S. No'])
		#print msdac_id,date,ts_name
		#return template(path+'history_one_ts.tpl',rows = test2, cases = test_cases2,ID=msdac_id,start=sdate,end=edate,TS_Name=ts_name)
		return template(path+'history_one_ts.tpl',rows = test2, cases = test_cases2,ID=msdac_id,TS_Name=ts_name)

	#history of Track section of particular MSDAC
	@app.route('/history_result/<url:re:.+>/one_dp')
	def history_of_one_ts(url):
		x = request.url
		#print "url---",x
		msdac_id = x.split("/")[4]
		msdac_id = msdac_id.split("%20")[0]
		#date = x.split("/")[-3].split("%20")
		dp_id = x.split("/")[-2]
		#sdate = date[1]
		#edate = date[3]


		obj = Search_Data()
		#x = obj.history_msdac_of_one_dp(sdate,edate,msdac_id,dp_id)
		x = obj.history_msdac_of_one_dp(msdac_id,dp_id)
		test2 = OrderedDict()
		test2['S. No'] = x["MSDAC"]["S No."]
		#test2['DP Status'] = x["MSDAC"]["DP Status"]
		test2['Error Code'] = x["MSDAC"]["Error Code"]
		test2['Date'] = x["MSDAC"]["Date"]
		test2['Time'] = x["MSDAC"]["Time"]
		test_cases2 = len(test2['S. No'])
		#print msdac_id,date,ts_name
		#return template(path+'history_one_dp.tpl',rows = test2, cases = test_cases2,ID=msdac_id,start=sdate,end=edate,DP_ID=dp_id)
		return template(path+'history_one_dp.tpl',rows = test2, cases = test_cases2,ID=msdac_id,DP_ID=dp_id)
		
	#history of Track section of particular MSDAC
	@app.route('/history_result/<url:re:.+>/ts')
	def history_of_msdac(url):
		x = request.url
		msdac_id = x.split("/")[-3]
		date = x.split("/")[-2].split("%20")
		#print date
		sdate = date[1]
		edate = date[3]
		
		obj = Search_Data()
		x = obj.history_msdac_ts_details(sdate,edate,msdac_id)
		#print "history",x		
		test2 = OrderedDict()
		test2['S. No'] = x["MSDAC"]["S No."]
		test2['TS Name'] = x["MSDAC"]["TS Name"]
		test2['TS Status'] = x["MSDAC"]["Track Section Status"]
		test2['Remark'] = x["MSDAC"]["Remark"]
		test2['Date'] = x["MSDAC"]["Date"]
		test2['Time'] = x["MSDAC"]["Time"]
		test_cases2 = len(test2['S. No'])
		
		return template(path+'history_MSDAC.tpl',rows = test2, cases = test_cases2,ID=msdac_id,start=sdate,end=edate)

	#history of Track section of particular MSDAC
	@app.route('/history_result/<url:re:.+>/dp')
	def history_of_msdac(url):
		x = request.url
		msdac_id = x.split("/")[-3]
		date = x.split("/")[-2].split("%20")
		#print date
		sdate = date[1]
		edate = date[3]
		
		obj = Search_Data()
		x = obj.history_msdac_dp_details(sdate,edate,msdac_id)
		#print "history",x		
		test2 = OrderedDict()
		test2['S. No'] = x["MSDAC"]["S No."]
		test2['DP ID'] = x["MSDAC"]["DP ID"]
		#test2['DP Status'] = x["MSDAC"]["DP Status"]
		test2['Error Code'] = x["MSDAC"]["Error Code"]
		test2['Date'] = x["MSDAC"]["Date"]
		test2['Time'] = x["MSDAC"]["Time"]
		test_cases2 = len(test2['S. No'])

		return template(path+'history_all_dp.tpl',rows = test2, cases = test_cases2,ID=msdac_id,start=sdate,end=edate)
		

	#History results
	@app.route('/history_result')
	def history_of_system():
		x = request.url
		#print "URL",x
		
		lst = []
		l = x.split("?")
		p = l[-1].split("&")

		for i in range(3):
			k = p[i].split("=")[-1].replace("%2F","-")# first split on basis of = and then replace string on basis of desired format
			lst.append(k)
		obj = Search_Data()
		#print "lst",lst
		d = obj.history_details(lst[0],lst[1],lst[2],Region)
		print "d",d
		if len(d) >= 1:
			ID = lst[2]
			sdate = lst[0]
			edate = lst[1]
			stn_name = d[0][1]
			mob_no = d[0][6]
			if d[0][11] == 'MSDAC':

				test = OrderedDict()

				test['S No.'] = [str(i) for i in range(1,len(d)+1)]
				test['Status'] = [x[13] for x in d]
				test['Date'] = [x[2] for x in d]
				test['Time'] = [x[3] for x in d]

				test_cases = len(test['S No.'])
			

				obj = Search_Data()
				#data = obj.search_result(sql)
				#stn_name = d[0][1]
				sql = "SELECT No_of_DP FROM System_Information WHERE System_ID = '"+lst[2]+"'"
				nod = obj.search_result(sql)[0][0]

				sql = "SELECT No_of_TS FROM System_Information WHERE System_ID = '"+lst[2]+"'"
				nots = obj.search_result(sql)[0][0]

				return template(path+'history_msdac_id.tpl',rows = test, cases = test_cases, ID=ID,stn_name=stn_name,nod=nod,nots=nots,sdate=sdate,edate= edate )

			if d[0][11] == 'HASSDAC':
		
				test = OrderedDict()
				test['S No.'] = [str(i) for i in range(1,len(d)+1)]
				test['Status'] = [x[13] for x in d]
				test['System1 Ststus'] = [x[15] for x in d]
				test['System2 Ststus'] = [x[16] for x in d]
				test['Date'] = [x[2] for x in d]
				test['Time'] = [x[3] for x in d]
				test_cases = len(test['S No.'])
			
				return template(path+'history_hassdac_id.tpl',rows = test, cases = test_cases, ID=ID,stn_name=stn_name,no=mob_no,sdate=sdate,edate= edate )

		else:
			return template(path+'no_result.tpl')

	
	@app.route('/dp_info')
	def generate_report():
		
		test_cases2 = len(dp['S. No'])
		#print test2

		
		return template(path+'upload1.tpl',rows = dp, cases = test_cases2,  ID = sys_id_ts, reg = region_ts)

	@app.route('/config_info')
	def generate_report():
		test_cases2 = len(config['S. No'])
		

		
		return template(path+'upload2.tpl',rows = config, cases = test_cases2,  ID = sys_id_ts, reg = region_ts)

	
	#insert data into system information table
	@app.route('/insert_details')
	def insert_data():
		x = request.url
		print "insertdetails",x
		
	
	#Generate Report
	@app.route('/generate_report',method = 'POST')
	def generate_report():
		x = request.url
		print "URL",x
		#URL http://10.26.22.138:8080/generate_report?sysid=MSDAC01&region=Northern&fileToUpload=d1.txt
		
		'''file_upload_data = []
		l = x.split("?")
		p = l[-1].split("&")

		for i in range(3):
			k = p[i].split("=")[-1]# first split on basis of = and then replace string on basis of desired format
			file_upload_data.append(k)
		global sys_id_ts
		global region_ts
		#print "K",file_upload_data
		sys_id_ts = file_upload_data[0]
		region_ts = file_upload_data[1]
		file_name = file_upload_data[2]
		command = ['locate', file_name]
		output = subprocess.Popen(command, stdout=subprocess.PIPE).communicate()[0]
		output = output.decode()
		search_results = output.split('\n')
		upload_path = search_results[0]'''

		global sys_id_ts
		global region_ts
		print "inside upload files",ab
		sys_id_ts = request.forms.get('sysid')
		region_ts = request.forms.get('region')
		files = request.files.get('fileToUpload')
		
		print sys_id_ts,region_ts,files,files.filename
		files.save("../upload_files",files.filename)

		file_name = files.filename
		#if upload_path == "":
		'''import commands
		#filename = "d1.txt"
		cmd = "find $PWD -type f -name "+file_name
		upload_path = commands.getoutput(cmd)
		print "output",upload_path'''
		upload_path = "../upload_files/"+file_name
		print "server",upload_path
		obj = insert()
		d = obj.search_pkt_in_file(file_upload_data,upload_path)
		#print "returndata",d
		global config
		config = OrderedDict()
		config['S. No'] = d["MSDAC"]["Config_Data"]["S No."]
		config['Date'] = d["MSDAC"]["Config_Data"]["Date"]
		config['Time'] = d["MSDAC"]["Config_Data"]["Time"]
		config['Card_No'] = d["MSDAC"]["Config_Data"]["Card_No"]
		config['CPU_No'] = d["MSDAC"]["Config_Data"]["CPU_No"]
		config['TC_Status'] = d["MSDAC"]["Config_Data"]["TC_Status"]
		config['TC_No'] = d["MSDAC"]["Config_Data"]["TC_No"]
		config['Status_Code'] = d["MSDAC"]["Config_Data"]["Status_Code"]
		config['Piloting_Scheme'] = d["MSDAC"]["Config_Data"]["Status_PS"]
		config['Relay_Read_Back'] = d["MSDAC"]["Config_Data"]["Status_RR"]
		config['Track_Section_Block'] = d["MSDAC"]["Config_Data"]["Status_TSB"]
		config['LV'] = d["MSDAC"]["Config_Data"]["Status_LV"]
		config['Block_DP_No'] = d["MSDAC"]["Config_Data"]["Status_Block_DP_No"]
		config['No_of_DP'] = d["MSDAC"]["Config_Data"]["No_of_DP"]
		config['DP_No'] = d["MSDAC"]["Config_Data"]["DP"]
		
		
		global dp
		dp = OrderedDict()
		dp['S. No'] = d["MSDAC"]["DP_Data"]["S No."]
		dp['Date'] = d["MSDAC"]["DP_Data"]["Date"]
		dp['Time'] = d["MSDAC"]["DP_Data"]["Time"]
		dp['DP ID'] = d["MSDAC"]["DP_Data"]["DP_ID"]
		#test2['DP Status'] = d["MSDAC"]["DP_Data"]["DP Status"]
		dp['Error Code'] = d["MSDAC"]["DP_Data"]["Error_Code"]
		dp['Remark'] = d["MSDAC"]["DP_Data"]["Remark"]
		dp['Primary Count'] = d["MSDAC"]["DP_Data"]["Primary_Count"]
		dp['Sync Flag'] = d["MSDAC"]["DP_Data"]["Sync_Flag"]		
		
		#test_cases2 = len(dp['S. No'])
		#print test2
		global test3
		#test3 = OrderedDict()
		test3 = OrderedDict()
		test3['S. No'] = d["MSDAC"]["TS_Data"]["S No."]
		test3['Date'] = d["MSDAC"]["TS_Data"]["Date"]
		test3['Time'] = d["MSDAC"]["TS_Data"]["Time"]
		test3['TS Name'] = d["MSDAC"]["TS_Data"]["TS_Name"]
		test3['Status'] = d["MSDAC"]["TS_Data"]["Status"]
		test3['Status Description'] = d["MSDAC"]["TS_Data"]["Error"]
		test3['TS Status'] = d["MSDAC"]["TS_Data"]["TS_Status"]
		test3['TS Error'] = d["MSDAC"]["TS_Data"]["TS_Error"]	
		test3['Remark'] = d["MSDAC"]["TS_Data"]["Remark"]
		#test3['Section Balance'] = d["MSDAC"]["TS_Data"]["Sec_Bal"]
		
		test_cases3 = len(test3['S. No'])
		#print "DPINformation",dp
		#print "tsinfo",test3
		return template(path+'upload.tpl', rows1= test3, cases1 = test_cases3, ID = sys_id_ts, reg = region_ts)
		
		'''obj = Search_Data()
		#print "lst",lst
		d = obj.history_details(lst[0],lst[1],lst[2],Region)
		print "d",d
		if len(d) >= 1:
			ID = lst[2]
			sdate = lst[0]
			edate = lst[1]
			stn_name = d[0][1]
			mob_no = d[0][6]
			if d[0][11] == 'MSDAC':

				test = OrderedDict()

				test['S No.'] = [str(i) for i in range(1,len(d)+1)]
				test['Status'] = [x[13] for x in d]
				test['Date'] = [x[2] for x in d]
				test['Time'] = [x[3] for x in d]

				test_cases = len(test['S No.'])
			

				obj = Search_Data()
				#data = obj.search_result(sql)
				#stn_name = d[0][1]
				sql = "SELECT No_of_DP FROM System_Information WHERE System_ID = '"+lst[2]+"'"
				nod = obj.search_result(sql)[0][0]

				sql = "SELECT No_of_TS FROM System_Information WHERE System_ID = '"+lst[2]+"'"
				nots = obj.search_result(sql)[0][0]

				return template(path+'history_msdac_id.tpl',rows = test, cases = test_cases, ID=ID,stn_name=stn_name,nod=nod,nots=nots,sdate=sdate,edate= edate )

			if d[0][11] == 'HASSDAC':
		
				test = OrderedDict()
				test['S No.'] = [str(i) for i in range(1,len(d)+1)]
				test['Status'] = [x[13] for x in d]
				test['System1 Ststus'] = [x[15] for x in d]
				test['System2 Ststus'] = [x[16] for x in d]
				test['Date'] = [x[2] for x in d]
				test['Time'] = [x[3] for x in d]
				test_cases = len(test['S No.'])
			
				return template(path+'history_hassdac_id.tpl',rows = test, cases = test_cases, ID=ID,stn_name=stn_name,no=mob_no,sdate=sdate,edate= edate )

		else:
			return template(path+'no_result.tpl')'''

	@app.route('/export_csv',method = 'POST')
	def generate_report():
		
		test_cases3 = len(test3['S. No'])
		#code for the csv file of TS Information
		f = open("log.py","w")
		f.write(repr(test3)+'\n')
		f.close()
		
		data = eval(open('log.py').read())
		k = data.values()
		# make all list of equal length
		max_len = max(map(len,k))
		mod_data=[]
		for row in k:
			m = len(row)
			for i in range(max_len):
				if len(row) < max_len:
					row.append('')
					m +=1
			mod_data.append(row)
		# write data column wise to csv file 
		with open('../csv_files/'+sys_id_ts+'_'+region_ts+'_TS.csv','wb') as f:
			w=csv.DictWriter(f,data.keys())
			w.writeheader()
			writer = csv.writer(f)
			writer.writerows(zip(mod_data[0],mod_data[1],mod_data[2],mod_data[3],mod_data[4],mod_data[5],mod_data[6],mod_data[7],mod_data[8]))

		#code for the csv file of DP Information
		f = open("log.py","w")
		f.write(repr(dp)+'\n')
		f.close()
		
		data = eval(open('log.py').read())
		k = data.values()
		# make all list of equal length
		max_len = max(map(len,k))
		mod_data=[]
		for row in k:
			m = len(row)
			for i in range(max_len):
				if len(row) < max_len:
					row.append('')
					m +=1
			mod_data.append(row)
		# write data column wise to csv file 
		with open('../csv_files/'+sys_id_ts+'_'+region_ts+'_DP.csv','wb') as f:
			w=csv.DictWriter(f,data.keys())
			w.writeheader()
			writer = csv.writer(f)
			writer.writerows(zip(mod_data[0],mod_data[1],mod_data[2],mod_data[3],mod_data[4],mod_data[5],mod_data[6],mod_data[7]))

		#code for the csv file of Config Information
		f = open("log.py","w")
		f.write(repr(config)+'\n')
		f.close()
		
		data = eval(open('log.py').read())
		k = data.values()
		# make all list of equal length
		max_len = max(map(len,k))
		mod_data=[]
		for row in k:
			m = len(row)
			for i in range(max_len):
				if len(row) < max_len:
					row.append('')
					m +=1
			mod_data.append(row)
		# write data column wise to csv file 
		with open('../csv_files/'+sys_id_ts+'_'+region_ts+'_Config.csv','wb') as f:
			w=csv.DictWriter(f,data.keys())
			w.writeheader()
			writer = csv.writer(f)
			writer.writerows(zip(mod_data[0],mod_data[1],mod_data[2],mod_data[3],mod_data[4],mod_data[5],mod_data[6],mod_data[7],mod_data[8],mod_data[9],mod_data[10],mod_data[11],mod_data[12],mod_data[13],mod_data[14]))
		
		return template(path+'upload.tpl', rows1= test3, cases1 = test_cases3, ID = sys_id_ts, reg = region_ts)

		

	
	@app.route('/UploadFiles', method='POST')
	def UploadFiles():
		print "inside upload files"
	   	uploadinc = request.files.get('uploadinc')

	   	uploadinc.save("C:\Users\cel-admin\Desktop/"+uploadinc.filename)


if __name__ == '__main__':
	run(app, host='10.26.22.138', port=8080, debug = True)




