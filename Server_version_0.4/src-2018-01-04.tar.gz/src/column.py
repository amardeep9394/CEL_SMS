{
	"User_credential":["Username","Password","Region"],
	"System_Information":["Region","Division","System_Type","Station_Name","System_ID",
				"Mobile_number","No_of_DP","No_of_TS","Date","Time"],
	"System_Status":["Region","Division","System_Type","System_ID","System_Status","Date","Time", "Updated_TS_Info"],
	"History_Information":["System_ID","Station_Name","System_Type","Date","Time","Region", "Division","Mobile_number",
				"DP_ID","DP_Status","TS_ID","TS_Status","System_Status","TS_Info"],
	"DP_Status":["DP_ID", "System_ID", "DP_Status","Date","Time"],
	"TS_Status":["TS_ID","System_ID", "TS_Status","Date","Time"]
	
}
